
CREATE PROCEDURE [dbo].[WriteLockSession]
@SessionID as varchar(32),
@Persisted bit
AS
	SET NOCOUNT OFF ; 
	IF @Persisted = 1
	BEGIN
		UPDATE [ReportServerTempDB].dbo.SessionLock WITH (ROWLOCK)
		SET SessionID = SessionID
		WHERE SessionID = @SessionID ;
	END
	ELSE
	BEGIN
		INSERT INTO [ReportServerTempDB].dbo.SessionLock WITH (ROWLOCK) (SessionID) VALUES (@SessionID)
	END
GO
