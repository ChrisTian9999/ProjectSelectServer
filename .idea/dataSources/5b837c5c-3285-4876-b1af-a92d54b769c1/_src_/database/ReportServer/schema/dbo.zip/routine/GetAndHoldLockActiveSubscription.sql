
CREATE PROCEDURE [dbo].[GetAndHoldLockActiveSubscription]
@ActiveID uniqueidentifier
AS

select 
    TotalNotifications, 
    TotalSuccesses, 
    TotalFailures 
from 
    ActiveSubscriptions with (XLOCK)
where
    ActiveID = @ActiveID

GO
