
CREATE TRIGGER [dbo].[syspolicy_insert_target_set_level_trigger] 
    ON [dbo].[syspolicy_target_set_levels_internal]
FOR INSERT
AS
BEGIN
	DECLARE @retval_check int;
	EXECUTE @retval_check = [dbo].[sp_syspolicy_check_membership] 'PolicyAdministratorRole'
	IF ( 0!= @retval_check)
	BEGIN
		RETURN;
	END

    DECLARE @update_notifications INT
    DECLARE @update_ddl_trigger   INT

    SET @update_notifications = 0
    SET @update_ddl_trigger = 0

    SELECT @update_notifications = SUM (p.execution_mode & 2), @update_ddl_trigger = SUM (p.execution_mode & 1)
        FROM inserted i
        JOIN dbo.syspolicy_target_sets s ON (i.target_set_id = s.target_set_id)
        JOIN msdb.dbo.syspolicy_object_sets_internal os ON (s.object_set_id = os.object_set_id)
        JOIN msdb.dbo.syspolicy_policies p ON (os.object_set_id = p.object_set_id)    
        WHERE 1 = dbo.syspolicy_fn_filter_complete (i.target_set_id) AND
            ((p.execution_mode & 3) > 0 AND p.is_enabled = 1 AND 1 = dbo.syspolicy_fn_eventing_filter (i.target_set_id))

    IF (@update_ddl_trigger > 0)
        EXEC sys.sp_syspolicy_update_ddl_trigger 

    IF    (@update_notifications > 0)    
        EXEC sys.sp_syspolicy_update_event_notification 

    DECLARE @row_count int    

    SELECT @row_count = count(*) 
    FROM inserted i 
    INNER JOIN dbo.syspolicy_target_sets s ON s.target_set_id = i.target_set_id
    INNER JOIN dbo.syspolicy_object_sets os ON s.object_set_id = os.object_set_id
    INNER JOIN syspolicy_policies p ON os.object_set_id = p.object_set_id
    INNER JOIN syspolicy_conditions c on p.condition_id = c.condition_id
    WHERE    p.is_enabled != 0 AND
            p.execution_mode != 4 AND
            (1 = CONVERT(xml, c.expression).exist('//FunctionType/text()[.="ExecuteSql"]') OR
            1 = CONVERT(xml, c.expression).exist('//FunctionType/text()[.="ExecuteWql"]') )
    OPTION (FORCE ORDER)

    IF (@row_count > 0)
    BEGIN
        RAISERROR(34017, -1, -1) 
        ROLLBACK TRANSACTION
    END
END
GO
